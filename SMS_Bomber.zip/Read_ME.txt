######################################################################
######################################################################
####                                                              ####
####  this is a fun project, meant for unprofessional use only!!  ####
####                                                              ####
######################################################################
######################################################################                                                      ##################
                                                                                                                                            ##
Note: Targeting more than 50 sms at a given number can lead to ban of that number from the used websites, rendering the services useless    ##
																																			##
                                                                                                                            ##################
###########################
## Used Websites:        ##
##                       ##
##  1) Flipkart Seller   ##
##  2) Byjus             ##
##  3) Amazon            ##
###########################


-------------------------------------------------------------------------------------------------------------------------------------------------
|																																				|
| How to use:																															  		|
|																																				|
|   1) Open 'target.py' file using any simple code editor																						|
|																																				|
|   2) Set phone to the target phone number																										|
|																																				|
|   3) Set the number of sms to be sent in sms_count.																							|
|      Note: Total SMS = 10 times the sms_count																									|
|            Keep this under 50, that is sms_count = 5 is most preferrable.																		|
|																																				|
|   4) Save 'taget.py' and close it.																											|
|																																				|
|   5) Run 'start_bombing.py' file to start bombing.																							|
|      Note: Preferrably, use a cmd line instead of directly running the file. So that, stopping the code is possible, once it is activated.	|
|																																				|
|------------------------------------------------------------------------------------------------------------------------------------------------