phone = '9999999999' #Ten digit number
sms_count = 5 # multiplied by 10