phone = '9853507708'
sms_count = 5 # multiplied by 10